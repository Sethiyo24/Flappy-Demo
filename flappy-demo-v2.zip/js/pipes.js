/**
 * Pipes — Obstacle system with standard and moving variants.
 * Speed increases by 20% of CURRENT speed every 10 points (compound).
 */

export class Pipe {
  constructor(x, gapY, gapHeight, width, isMoving = false) {
    this.x = x;
    this.gapY = gapY;
    this.gapHeight = gapHeight;
    this.width = width;
    this.isMoving = isMoving;
    this.passed = false;
    this.movePhase = Math.random() * Math.PI * 2;
    this.moveAmp = 40;
    this.moveSpeed = 0.002;
    this.baseGapY = gapY;
  }

  update(speed, dt, gameHeight) {
    this.x -= speed * dt;
    if (this.isMoving) {
      this.movePhase += this.moveSpeed * dt;
      this.gapY = this.baseGapY + Math.sin(this.movePhase) * this.moveAmp;
      const minGap = 60;
      const maxGap = gameHeight - 60 - this.gapHeight;
      this.gapY = Math.max(minGap, Math.min(maxGap, this.gapY));
    }
  }

  draw(ctx, gameHeight) {
    const capHeight = 24;
    const color = this.isMoving ? '#FF9800' : '#56AB2F';
    const darkColor = this.isMoving ? '#F57C00' : '#2E7D32';
    const capColor = this.isMoving ? '#FFB74D' : '#A5D6A7';

    ctx.fillStyle = color;
    ctx.fillRect(this.x, 0, this.width, this.gapY - capHeight);
    ctx.fillStyle = capColor;
    ctx.fillRect(this.x - 2, this.gapY - capHeight, this.width + 4, capHeight);
    ctx.strokeStyle = darkColor;
    ctx.lineWidth = 2;
    ctx.strokeRect(this.x - 2, this.gapY - capHeight, this.width + 4, capHeight);

    const bottomY = this.gapY + this.gapHeight;
    ctx.fillStyle = color;
    ctx.fillRect(this.x, bottomY + capHeight, this.width, gameHeight - bottomY - capHeight);
    ctx.fillStyle = capColor;
    ctx.fillRect(this.x - 2, bottomY, this.width + 4, capHeight);
    ctx.strokeStyle = darkColor;
    ctx.strokeRect(this.x - 2, bottomY, this.width + 4, capHeight);

    ctx.fillStyle = 'rgba(255,255,255,0.15)';
    ctx.fillRect(this.x + 4, 0, 6, this.gapY - capHeight);
    ctx.fillRect(this.x + 4, bottomY + capHeight, 6, gameHeight - bottomY - capHeight);
  }

  isOffScreen() {
    return this.x + this.width < -50;
  }

  collidesWith(hitbox) {
    const pipeLeft = this.x;
    const pipeRight = this.x + this.width;
    const boxLeft = hitbox.x;
    const boxRight = hitbox.x + hitbox.w;
    const boxTop = hitbox.y;
    const boxBottom = hitbox.y + hitbox.h;

    if (boxRight > pipeLeft && boxLeft < pipeRight) {
      if (boxTop < this.gapY - 24) return true;
      if (boxBottom > this.gapY + this.gapHeight + 24) return true;
    }
    return false;
  }
}

export class PipeManager {
  constructor(gameWidth, gameHeight) {
    this.gameW = gameWidth;
    this.gameH = gameHeight;
    this.pipes = [];
    this.spawnTimer = 0;
    this.spawnInterval = 130;
    this.baseSpeed = 2.5;
    this.speed = this.baseSpeed;
    this.pipeWidth = 60;
    this.score = 0;
    this.currentTier = 0;
    this.onSpeedUp = null; // callback for speed up animation
  }

  reset() {
    this.pipes = [];
    this.spawnTimer = 0;
    this.spawnInterval = 130;
    this.baseSpeed = 2.5;
    this.speed = this.baseSpeed;
    this.score = 0;
    this.currentTier = 0;
  }

  /**
   * Compound speed increase: +20% of CURRENT speed every 10 points
   * 0-9: 2.5
   * 10-19: 2.5 * 1.2 = 3.0
   * 20-29: 3.0 * 1.2 = 3.6
   * 30-39: 3.6 * 1.2 = 4.32
   */
  updateSpeedForScore(score) {
    const tier = Math.floor(score / 10);
    if (tier > this.currentTier) {
      this.currentTier = tier;
      // Compound: multiply current speed by 1.2
      this.baseSpeed *= 1.2;
      // Reduce spawn interval slightly
      this.spawnInterval = Math.max(80, this.spawnInterval * 0.92);

      // Trigger speed up animation
      if (this.onSpeedUp) {
        this.onSpeedUp(this.baseSpeed);
      }
    }
  }

  update(dt, bird) {
    this.spawnTimer -= dt;
    if (this.spawnTimer <= 0) {
      this.spawnPipe();
      this.spawnTimer = this.spawnInterval + Math.random() * 20;
    }

    for (let i = this.pipes.length - 1; i >= 0; i--) {
      const pipe = this.pipes[i];
      pipe.update(this.speed, dt, this.gameH);

      if (!pipe.passed && pipe.x + pipe.width < bird.x) {
        pipe.passed = true;
        this.score++;
      }

      if (pipe.isOffScreen()) {
        this.pipes.splice(i, 1);
      }
    }
  }

  spawnPipe() {
    const minGap = Math.max(100, 140 - this.currentTier * 4);
    const maxGap = Math.max(130, 170 - this.currentTier * 3);
    const gapHeight = minGap + Math.random() * (maxGap - minGap);
    const margin = 70;
    const gapY = margin + Math.random() * (this.gameH - gapHeight - margin * 2);

    const isMoving = this.score >= 10 && Math.random() < Math.min(0.6, 0.3 + this.currentTier * 0.1);
    this.pipes.push(new Pipe(this.gameW + 20, gapY, gapHeight, this.pipeWidth, isMoving));
  }

  collidesWith(hitbox) {
    for (const pipe of this.pipes) {
      if (pipe.collidesWith(hitbox)) return true;
    }
    return false;
  }

  draw(ctx) {
    for (const pipe of this.pipes) {
      pipe.draw(ctx, this.gameH);
    }
  }

  setSpeedMultiplier(multiplier) {
    this.speed = this.baseSpeed * multiplier;
  }

  getNextPipeX() {
    for (const pipe of this.pipes) {
      if (!pipe.passed) return pipe.x;
    }
    return this.gameW;
  }
}
