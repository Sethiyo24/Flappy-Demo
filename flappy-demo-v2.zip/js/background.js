/**
 * Background — Parallax scrolling layers.
 * Procedurally drawn: clouds, hills, trees. No image assets.
 */

export class Background {
  constructor(gameWidth, gameHeight) {
    this.w = gameWidth;
    this.h = gameHeight;
    this.layers = [];
    this.initLayers();
  }

  initLayers() {
    // Layer 1: Far clouds
    this.layers.push({
      speed: 0.2,
      offset: 0,
      draw: (ctx, w, h, off) => this.drawClouds(ctx, w, h, off, 0.4),
      enabled: true
    });

    // Layer 2: Mid hills
    this.layers.push({
      speed: 0.5,
      offset: 0,
      draw: (ctx, w, h, off) => this.drawHills(ctx, w, h, off),
      enabled: true
    });

    // Layer 3: Near trees/city (disabled on mobile)
    this.layers.push({
      speed: 0.8,
      offset: 0,
      draw: (ctx, w, h, off) => this.drawTrees(ctx, w, h, off),
      enabled: window.innerWidth > 480
    });
  }

  update(speed, dt) {
    for (const layer of this.layers) {
      if (!layer.enabled) continue;
      layer.offset -= speed * layer.speed * dt;
      if (layer.offset <= -this.w) layer.offset += this.w;
    }
  }

  draw(ctx) {
    for (const layer of this.layers) {
      if (!layer.enabled) continue;
      layer.draw(ctx, this.w, this.h, layer.offset);
      // Draw second copy for seamless wrap
      layer.draw(ctx, this.w, this.h, layer.offset + this.w);
    }
  }

  drawClouds(ctx, w, h, offset, opacity) {
    ctx.save();
    ctx.globalAlpha = opacity;
    ctx.fillStyle = '#FFFFFF';
    const cloudY = h * 0.15;
    const positions = [0.1, 0.35, 0.6, 0.85];
    for (const pos of positions) {
      const x = pos * w + offset;
      this._drawCloudShape(ctx, x, cloudY + Math.sin(pos * 3) * 20, 30 + pos * 15);
    }
    ctx.restore();
  }

  _drawCloudShape(ctx, x, y, size) {
    ctx.beginPath();
    ctx.arc(x, y, size * 0.5, 0, Math.PI * 2);
    ctx.arc(x + size * 0.4, y - size * 0.2, size * 0.4, 0, Math.PI * 2);
    ctx.arc(x + size * 0.7, y, size * 0.45, 0, Math.PI * 2);
    ctx.arc(x + size * 0.35, y + size * 0.15, size * 0.35, 0, Math.PI * 2);
    ctx.fill();
  }

  drawHills(ctx, w, h, offset) {
    ctx.save();
    ctx.fillStyle = '#81C784';
    ctx.globalAlpha = 0.6;
    ctx.beginPath();
    ctx.moveTo(offset, h);
    ctx.bezierCurveTo(
      offset + w * 0.25, h - 80,
      offset + w * 0.5, h - 40,
      offset + w * 0.75, h - 100
    );
    ctx.bezierCurveTo(
      offset + w * 1.0, h - 60,
      offset + w * 1.25, h - 90,
      offset + w * 1.5, h - 50
    );
    ctx.lineTo(offset + w * 1.5, h);
    ctx.closePath();
    ctx.fill();

    // Second hill layer (darker)
    ctx.fillStyle = '#66BB6A';
    ctx.globalAlpha = 0.5;
    ctx.beginPath();
    ctx.moveTo(offset, h);
    ctx.bezierCurveTo(
      offset + w * 0.3, h - 60,
      offset + w * 0.6, h - 120,
      offset + w * 0.9, h - 70
    );
    ctx.bezierCurveTo(
      offset + w * 1.1, h - 50,
      offset + w * 1.3, h - 90,
      offset + w * 1.5, h - 40
    );
    ctx.lineTo(offset + w * 1.5, h);
    ctx.closePath();
    ctx.fill();
    ctx.restore();
  }

  drawTrees(ctx, w, h, offset) {
    ctx.save();
    ctx.globalAlpha = 0.7;
    const treePositions = [0.15, 0.4, 0.65, 0.9];
    for (const pos of treePositions) {
      const x = pos * w + offset;
      const treeH = 40 + Math.sin(pos * 5) * 15;
      this._drawTree(ctx, x, h - 10, treeH);
    }
    ctx.restore();
  }

  _drawTree(ctx, x, y, height) {
    // Trunk
    ctx.fillStyle = '#795548';
    ctx.fillRect(x - 3, y - height * 0.3, 6, height * 0.3);
    // Foliage
    ctx.fillStyle = '#4CAF50';
    ctx.beginPath();
    ctx.moveTo(x, y - height);
    ctx.lineTo(x - 15, y - height * 0.3);
    ctx.lineTo(x + 15, y - height * 0.3);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#66BB6A';
    ctx.beginPath();
    ctx.moveTo(x, y - height * 0.8);
    ctx.lineTo(x - 12, y - height * 0.25);
    ctx.lineTo(x + 12, y - height * 0.25);
    ctx.closePath();
    ctx.fill();
  }

  setMobileMode(isMobile) {
    // Disable layer 3 on mobile
    if (this.layers.length >= 3) {
      this.layers[2].enabled = !isMobile;
    }
  }
}
